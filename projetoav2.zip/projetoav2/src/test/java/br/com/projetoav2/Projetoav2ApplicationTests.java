package br.com.projetoav2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projetoav2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
